# Prometheus Monitoring Installers

Current baseline: **v6r4-RC5** — security-targeted Linux UAT release candidate.

This repository contains production-oriented Linux installers for seven monitoring components, active source/tests, and archived historical delivery material.

## Production installers

Use only the files under [`installers/`](installers/) on target servers:

- Alertmanager
- Blackbox Exporter
- Grafana
- Node Exporter
- Prometheus
- SNMP Exporter
- VictoriaMetrics single-node

Each production installer is a **single self-contained shell script**. No sibling `common/platform.sh` is required or loaded at runtime.

## Repository layout

- `installers/` — seven self-contained production/UAT installer scripts only.
- `src/v6r4-RC5/` — active source, shared build-time `common/platform.sh`, configs and tests.
- `tools/` — supporting tools such as node discovery.
- `docs/` — current RC5 baseline, validation and targeted UAT instructions.
- `releases/v6r4-RC5/` — RC5 ZIP and SHA256.
- `archive/` — historical snapshots; never treat archived files as the current baseline.

## RC5 scope

RC4 targeted Linux UAT passed its stated lifecycle fixes, but discovered a new P0 path-safety issue: a pre-existing symlink at a component state path could redirect installer-owned state writes outside `/usr/local/<component>`.

RC5 is deliberately security-only: state creation and ownership registry access now fail closed on symlink/path escape. No unrelated component or lifecycle behavior is changed.

RC5 is **not GA**. See [`docs/RC5_BASELINE.md`](docs/RC5_BASELINE.md) and [`docs/RC5_SERVER_UAT.md`](docs/RC5_SERVER_UAT.md).
