# Prometheus Monitoring Installers

Current baseline: **v6r4-RC4** — targeted Linux UAT release candidate.

This repository contains production-oriented Linux installers for seven monitoring components, active source/tests, and archived historical delivery material.

## Production installers

Use only the files under [`installers/`](installers/) on target servers:

- Alertmanager
- Blackbox Exporter
- Grafana
- Node Exporter
- Prometheus
- SNMP Exporter
- VictoriaMetrics single-node

Each production installer is a **single self-contained shell script**. No sibling `common/platform.sh` is required or loaded at runtime.

## Repository layout

- `installers/` — seven self-contained production/UAT installer scripts only.
- `src/v6r4-RC4/` — active source, shared build-time `common/platform.sh`, configs and tests.
- `tools/` — supporting tools such as node discovery.
- `docs/` — current RC4 baseline, validation and targeted UAT instructions.
- `releases/v6r4-RC4/` — RC4 ZIP and SHA256.
- `archive/` — historical snapshots; never treat archived files as the current baseline.

## RC4 scope

RC3 Linux UAT completed with **PASS WITH FIXES**. RC4 is deliberately narrow:

1. fix full-uninstall residue under `state/<component>-<port>/` for components that use shared instance state;
2. preserve sibling instance state and the shared ownership registry;
3. complete Grafana full lifecycle UAT using a local/pre-staged official tarball if external download bandwidth is insufficient.

RC4 is **not GA**. See [`docs/RC4_BASELINE.md`](docs/RC4_BASELINE.md) and [`docs/RC4_SERVER_UAT.md`](docs/RC4_SERVER_UAT.md).
